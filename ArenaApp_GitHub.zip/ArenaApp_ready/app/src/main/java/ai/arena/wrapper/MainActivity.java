package ai.arena.wrapper;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.FrameLayout;

public class MainActivity extends Activity {

    private static final String ARENA_URL = "https://arena.ai/";
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String PREFS = "vasilisa_prefs";
    private static final String DARK_MODE = "dark_mode";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private FrameLayout root;
    private View splash;
    private SharedPreferences prefs;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        splash = findViewById(R.id.splash);
        webView = findViewById(R.id.webview);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        applySystemBars(prefs.getBoolean(DARK_MODE, true));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUserAgentString(settings.getUserAgentString() + " VasilisaAndroid/2.0");

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(this, "AndroidTheme");
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectVasilisaUI();
                splash.postDelayed(() -> hideSplash(), 450);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                return super.onJsAlert(view, url, message, result);
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                return super.onJsConfirm(view, url, message, result);
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message,
                                      String defaultValue, android.webkit.JsPromptResult result) {
                return super.onJsPrompt(view, url, message, defaultValue, result);
            }

            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    startActivityForResult(fileChooserParams.createIntent(), FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Не удалось открыть выбор файла", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl(ARENA_URL);
        } else {
            webView.restoreState(savedInstanceState);
            splash.postDelayed(() -> hideSplash(), 900);
        }
    }

    private void applySystemBars(boolean dark) {
        if (dark) {
            getWindow().setStatusBarColor(Color.rgb(11, 16, 32));
            getWindow().setNavigationBarColor(Color.rgb(11, 16, 32));
            getWindow().getDecorView().setSystemUiVisibility(0);
        } else {
            getWindow().setStatusBarColor(Color.WHITE);
            getWindow().setNavigationBarColor(Color.WHITE);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private void hideSplash() {
        if (splash == null || splash.getVisibility() != View.VISIBLE) return;
        AlphaAnimation fade = new AlphaAnimation(1f, 0f);
        fade.setDuration(380);
        fade.setFillAfter(true);
        fade.setAnimationListener(new android.view.animation.Animation.AnimationListener() {
            @Override public void onAnimationStart(android.view.animation.Animation animation) {}
            @Override public void onAnimationRepeat(android.view.animation.Animation animation) {}
            @Override public void onAnimationEnd(android.view.animation.Animation animation) {
                splash.setVisibility(View.GONE);
            }
        });
        splash.startAnimation(fade);
    }

    private void injectVasilisaUI() {
        final boolean dark = prefs.getBoolean(DARK_MODE, true);
        String script = "javascript:(function(){"
                + "if(window.__vasilisaInstalled)return;window.__vasilisaInstalled=true;"
                + "document.title='Василиса';"
                + "var style=document.createElement('style');style.id='vasilisa-style';style.textContent=`"
                + "html,body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif!important;}"
                + "button{border-radius:14px!important;transition:transform .16s ease,box-shadow .16s ease,background .16s ease!important;}"
                + "button:active{transform:scale(.97)!important;}button svg{width:20px!important;height:20px!important;stroke-width:1.8!important;}"
                + "input,textarea{border-radius:16px!important;}"
                + "[class*='rounded-lg'],[class*='rounded-xl'],[class*='rounded-2xl']{transition:background .2s ease,border-color .2s ease,box-shadow .2s ease!important;}"
                + ".vasilisa-theme{position:fixed;right:16px;bottom:18px;width:46px;height:46px;border:1px solid rgba(127,140,170,.28);border-radius:50%!important;display:flex;align-items:center;justify-content:center;z-index:2147483647;background:rgba(255,255,255,.88);box-shadow:0 8px 28px rgba(25,35,60,.18);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);padding:0!important;}"
                + ".vasilisa-theme svg{width:21px;height:21px;}"
                + ".vasilisa-brand{font-weight:700!important;letter-spacing:.01em!important;}"
                + "html.vasilisa-dark body{background:#0b1020!important;color:#eef2ff!important;}"
                + "html.vasilisa-dark [class*='bg-white'],html.vasilisa-dark [class*='bg-gray-50'],html.vasilisa-dark [class*='bg-gray-100']{background-color:#12182a!important;}"
                + "html.vasilisa-dark [class*='border-gray'],html.vasilisa-dark [class*='border-slate']{border-color:rgba(148,163,184,.18)!important;}"
                + "html.vasilisa-dark .vasilisa-theme{background:rgba(22,29,48,.9);color:#fff;}"
                + "html.vasilisa-light body{background:#f7f8fc!important;color:#172033!important;}"
                + "html.vasilisa-light .vasilisa-theme{background:rgba(255,255,255,.92);color:#26324a;}"
                + "`;document.head.appendChild(style);"
                + "var map={"
                + "'Battle Mode':'Режим битвы','Select':'Выбрать','Get started':'Начать','Experience the frontier':'Исследуйте передовые модели',"
                + "'Settings':'Настройки','New chat':'Новый чат','Sign in':'Войти','Sign up':'Регистрация','Login':'Войти','Logout':'Выйти',"
                + "'Send':'Отправить','Share':'Поделиться','Copy':'Копировать','Delete':'Удалить','Edit':'Изменить','Cancel':'Отмена','Save':'Сохранить',"
                + "'Upload':'Загрузить','Upload image':'Загрузить изображение','Attach':'Прикрепить','Retry':'Повторить','Stop':'Остановить',"
                + "'Arena':'Василиса','Theme':'Тема','Light':'Светлая','Dark':'Тёмная','Language':'Язык','Search':'Поиск','Menu':'Меню','Close':'Закрыть',"
                + "'Create a landing page':'Создать лендинг','Build a dashboard':'Создать панель управления','Make a game':'Создать игру',"
                + "'Design to Code':'Из дизайна в код','Build a fullstack app':'Создать full-stack приложение','Launch a storefront':'Создать интернет-магазин',"
                + "'Upload an image and have AI build it':'Загрузите изображение, и ИИ соберёт его',"
                + "'Turn data into interactive charts':'Превратить данные в интерактивные графики','Build a playable browser game':'Создать браузерную игру',"
                + "'Create a sleek, modern landing page':'Создать стильный современный лендинг','Create a beautiful online shop':'Создать красивый интернет-магазин'"
                + "};"
                + "function tr(){var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);var n;while(n=w.nextNode()){var p=n.parentElement;if(!p||/SCRIPT|STYLE|TEXTAREA|CODE|PRE/.test(p.tagName))continue;var t=n.nodeValue.trim();if(map[t])n.nodeValue=n.nodeValue.replace(t,map[t]);}"
                + "document.querySelectorAll('input,textarea').forEach(function(e){if(map[e.placeholder])e.placeholder=map[e.placeholder];});"
                + "document.querySelectorAll('[aria-label],[title]').forEach(function(e){if(map[e.getAttribute('aria-label')])e.setAttribute('aria-label',map[e.getAttribute('aria-label')]);if(map[e.title])e.title=map[e.title];});"
                + "document.querySelectorAll('*').forEach(function(e){if(e.childNodes.length===1&&e.textContent.trim()==='Arena')e.classList.add('vasilisa-brand');});}"
                + "function themeButton(){if(document.getElementById('vasilisa-theme-btn'))return;var b=document.createElement('button');b.id='vasilisa-theme-btn';b.className='vasilisa-theme';b.setAttribute('aria-label','Переключить тему');b.innerHTML='"
                + (dark ? "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41\"/></svg>" : "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><path d=\"M21 12.8A8.5 8.5 0 1 1 11.2 3 6.7 6.7 0 0 0 21 12.8Z\"/></svg>")
                + ";b.onclick=function(){var d=!document.documentElement.classList.contains('vasilisa-dark');document.documentElement.classList.toggle('vasilisa-dark',d);document.documentElement.classList.toggle('vasilisa-light',!d);AndroidTheme.setDark(d);b.innerHTML=d?'<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41\"/></svg>':'<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><path d=\"M21 12.8A8.5 8.5 0 1 1 11.2 3 6.7 6.7 0 0 0 21 12.8Z\"/></svg>';};document.body.appendChild(b);}"
                + "document.documentElement.classList.toggle('vasilisa-dark'," + dark + ");document.documentElement.classList.toggle('vasilisa-light'," + (!dark) + ");tr();themeButton();new MutationObserver(function(){tr();themeButton();}).observe(document.body,{childList:true,subtree:true});"
                + "})();void(0);";
        webView.evaluateJavascript(script, null);
    }

    @android.webkit.JavascriptInterface
    public void setDarkFromJs(boolean dark) {
        prefs.edit().putBoolean(DARK_MODE, dark).apply();
        runOnUiThread(() -> applySystemBars(dark));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] results = null;
        if (resultCode == Activity.RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        super.onDestroy();
    }
}
